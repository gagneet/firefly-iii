mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: firefly_db
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
mysqldump: Error: 'Access denied; you need (at least one of) the PROCESS privilege(s) for this operation' when trying to dump tablespaces

--
-- Table structure for table `2fa_tokens`
--

DROP TABLE IF EXISTS `2fa_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2fa_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `expires_at` datetime NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `2fa_tokens_token_unique` (`token`),
  KEY `2fa_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `2fa_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2fa_tokens`
--

LOCK TABLES `2fa_tokens` WRITE;
/*!40000 ALTER TABLE `2fa_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `2fa_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_balances`
--

DROP TABLE IF EXISTS `account_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_balances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` int unsigned NOT NULL,
  `transaction_currency_id` int unsigned NOT NULL,
  `date` date DEFAULT NULL,
  `date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_journal_id` int unsigned DEFAULT NULL,
  `balance` decimal(32,12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_account_currency` (`account_id`,`transaction_currency_id`,`transaction_journal_id`,`date`,`title`),
  KEY `account_balances_transaction_journal_id_foreign` (`transaction_journal_id`),
  KEY `account_balances_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `account_balances_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_balances_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_balances_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_balances`
--

LOCK TABLES `account_balances` WRITE;
/*!40000 ALTER TABLE `account_balances` DISABLE KEYS */;
INSERT INTO `account_balances` VALUES (1,'2025-10-04 22:05:00','2025-10-04 22:05:00','running_balance',2,1,'2025-10-04','America/Los_Angeles',NULL,-7944.450000000000),(2,'2025-10-04 22:05:00','2025-10-04 22:05:00','running_balance',1,1,'2025-10-04','America/Los_Angeles',NULL,7944.450000000000),(3,'2025-10-04 22:05:00','2025-10-04 22:05:00','running_balance',4,1,'2025-10-04','America/Los_Angeles',NULL,-52000.000000000000),(4,'2025-10-04 22:05:00','2025-10-04 22:05:00','running_balance',3,1,'2025-10-04','America/Los_Angeles',NULL,52000.000000000000);
/*!40000 ALTER TABLE `account_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_meta`
--

DROP TABLE IF EXISTS `account_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_meta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `account_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_meta_account_id_index` (`account_id`),
  CONSTRAINT `account_meta_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_meta`
--

LOCK TABLES `account_meta` WRITE;
/*!40000 ALTER TABLE `account_meta` DISABLE KEYS */;
INSERT INTO `account_meta` VALUES (1,'2025-10-04 19:48:48','2025-10-04 19:48:48',1,'account_role','\"defaultAsset\"'),(2,'2025-10-04 19:48:48','2025-10-04 19:48:48',1,'currency_id','\"1\"'),(3,'2025-10-04 19:48:48','2025-10-04 19:48:48',2,'currency_id','\"1\"'),(4,'2025-10-04 19:48:48','2025-10-04 19:48:48',3,'account_role','\"savingAsset\"'),(5,'2025-10-04 19:48:48','2025-10-04 19:48:48',3,'currency_id','\"1\"'),(6,'2025-10-04 19:48:48','2025-10-04 19:48:48',4,'currency_id','\"1\"'),(7,'2025-10-04 19:48:48','2025-10-04 19:48:48',5,'account_role','\"cashWalletAsset\"'),(8,'2025-10-04 19:48:48','2025-10-04 19:48:48',5,'currency_id','\"1\"');
/*!40000 ALTER TABLE `account_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_piggy_bank`
--

DROP TABLE IF EXISTS `account_piggy_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_piggy_bank` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int unsigned NOT NULL,
  `piggy_bank_id` int unsigned NOT NULL,
  `current_amount` decimal(32,12) NOT NULL DEFAULT '0.000000000000',
  `native_current_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_piggy_save` (`account_id`,`piggy_bank_id`),
  KEY `account_piggy_bank_piggy_bank_id_foreign` (`piggy_bank_id`),
  CONSTRAINT `account_piggy_bank_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_piggy_bank_piggy_bank_id_foreign` FOREIGN KEY (`piggy_bank_id`) REFERENCES `piggy_banks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_piggy_bank`
--

LOCK TABLES `account_piggy_bank` WRITE;
/*!40000 ALTER TABLE `account_piggy_bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_piggy_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_types`
--

DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_types_type_unique` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_types`
--

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
INSERT INTO `account_types` VALUES (1,'2025-10-04 19:30:10','2025-10-04 19:30:10','Asset account'),(2,'2025-10-04 19:30:10','2025-10-04 19:30:10','Beneficiary account'),(3,'2025-10-04 19:30:10','2025-10-04 19:30:10','Cash account'),(4,'2025-10-04 19:30:10','2025-10-04 19:30:10','Credit card'),(5,'2025-10-04 19:30:10','2025-10-04 19:30:10','Debt'),(6,'2025-10-04 19:30:10','2025-10-04 19:30:10','Default account'),(7,'2025-10-04 19:30:10','2025-10-04 19:30:10','Expense account'),(8,'2025-10-04 19:30:10','2025-10-04 19:30:10','Import account'),(9,'2025-10-04 19:30:10','2025-10-04 19:30:10','Initial balance account'),(10,'2025-10-04 19:30:10','2025-10-04 19:30:10','Liability credit account'),(11,'2025-10-04 19:30:10','2025-10-04 19:30:10','Loan'),(12,'2025-10-04 19:30:10','2025-10-04 19:30:10','Mortgage'),(13,'2025-10-04 19:30:10','2025-10-04 19:30:10','Reconciliation account'),(14,'2025-10-04 19:30:10','2025-10-04 19:30:10','Revenue account');
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `account_type_id` int unsigned NOT NULL,
  `name` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `virtual_balance` decimal(32,12) DEFAULT NULL,
  `iban` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `order` int unsigned NOT NULL DEFAULT '0',
  `native_virtual_balance` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_user_id_index` (`user_id`),
  KEY `accounts_user_group_id_index` (`user_group_id`),
  KEY `accounts_account_type_id_index` (`account_type_id`),
  CONSTRAINT `accounts_account_type_id_foreign` FOREIGN KEY (`account_type_id`) REFERENCES `account_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accounts_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,1,1,1,'Commonwealth Bank of Australia',0.000000000000,NULL,1,0,1,NULL),(2,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,1,1,9,'Initial balance for \"Commonwealth Bank of Australia\"',NULL,NULL,1,0,0,NULL),(3,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,1,1,1,'Commonwealth Bank of Australia savings account',0.000000000000,NULL,1,0,2,NULL),(4,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,1,1,9,'Initial balance for \"Commonwealth Bank of Australia savings account\"',NULL,NULL,1,0,0,NULL),(5,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,1,1,1,'Cash wallet',0.000000000000,NULL,1,0,3,NULL);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `attachable_id` int unsigned NOT NULL,
  `attachable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `md5` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `mime` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int unsigned NOT NULL,
  `uploaded` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `attachments_user_id_foreign` (`user_id`),
  KEY `attachments_to_ugi` (`user_group_id`),
  CONSTRAINT `attachments_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attachments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log_entries`
--

DROP TABLE IF EXISTS `audit_log_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `auditable_id` int unsigned NOT NULL,
  `auditable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changer_id` int unsigned NOT NULL,
  `changer_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before` text COLLATE utf8mb4_unicode_ci,
  `after` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log_entries`
--

LOCK TABLES `audit_log_entries` WRITE;
/*!40000 ALTER TABLE `audit_log_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_budgets`
--

DROP TABLE IF EXISTS `auto_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auto_budgets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `budget_id` int unsigned NOT NULL,
  `transaction_currency_id` int unsigned NOT NULL,
  `auto_budget_type` tinyint unsigned NOT NULL DEFAULT '1',
  `amount` decimal(32,12) NOT NULL,
  `period` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `native_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auto_budgets_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `auto_budgets_budget_id_foreign` (`budget_id`),
  CONSTRAINT `auto_budgets_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auto_budgets_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_budgets`
--

LOCK TABLES `auto_budgets` WRITE;
/*!40000 ALTER TABLE `auto_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `available_budgets`
--

DROP TABLE IF EXISTS `available_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `available_budgets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `transaction_currency_id` int unsigned NOT NULL,
  `amount` decimal(32,12) NOT NULL,
  `start_date` date NOT NULL,
  `start_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_date` date NOT NULL,
  `end_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `native_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `available_budgets_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `available_budgets_user_id_foreign` (`user_id`),
  KEY `available_budgets_to_ugi` (`user_group_id`),
  CONSTRAINT `available_budgets_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `available_budgets_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `available_budgets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `available_budgets`
--

LOCK TABLES `available_budgets` WRITE;
/*!40000 ALTER TABLE `available_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `available_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bills` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `transaction_currency_id` int unsigned DEFAULT NULL,
  `name` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `match` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_min` decimal(32,12) NOT NULL,
  `amount_max` decimal(32,12) NOT NULL,
  `date` date NOT NULL,
  `date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `end_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension_date` date DEFAULT NULL,
  `extension_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_freq` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skip` smallint unsigned NOT NULL DEFAULT '0',
  `automatch` tinyint(1) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `name_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `match_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `order` int unsigned NOT NULL DEFAULT '0',
  `native_amount_min` decimal(32,12) DEFAULT NULL,
  `native_amount_max` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bills_user_id_foreign` (`user_id`),
  KEY `bills_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `bills_to_ugi` (`user_group_id`),
  CONSTRAINT `bills_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bills_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_limits`
--

DROP TABLE IF EXISTS `budget_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budget_limits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `budget_id` int unsigned NOT NULL,
  `transaction_currency_id` int unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `start_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `end_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(32,12) NOT NULL,
  `period` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generated` tinyint(1) NOT NULL DEFAULT '0',
  `native_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `budget_limits_budget_id_foreign` (`budget_id`),
  KEY `budget_limits_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `budget_limits_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budget_limits_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_limits`
--

LOCK TABLES `budget_limits` WRITE;
/*!40000 ALTER TABLE `budget_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_transaction`
--

DROP TABLE IF EXISTS `budget_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budget_transaction` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `budget_id` int unsigned NOT NULL,
  `transaction_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `budget_transaction_budget_id_foreign` (`budget_id`),
  KEY `budget_transaction_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `budget_transaction_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budget_transaction_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_transaction`
--

LOCK TABLES `budget_transaction` WRITE;
/*!40000 ALTER TABLE `budget_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_transaction_journal`
--

DROP TABLE IF EXISTS `budget_transaction_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budget_transaction_journal` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `budget_id` int unsigned NOT NULL,
  `budget_limit_id` int unsigned DEFAULT NULL,
  `transaction_journal_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `budget_transaction_journal_budget_id_foreign` (`budget_id`),
  KEY `budget_transaction_journal_transaction_journal_id_foreign` (`transaction_journal_id`),
  KEY `budget_id_foreign` (`budget_limit_id`),
  CONSTRAINT `budget_id_foreign` FOREIGN KEY (`budget_limit_id`) REFERENCES `budget_limits` (`id`) ON DELETE SET NULL,
  CONSTRAINT `budget_transaction_journal_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budget_transaction_journal_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_transaction_journal`
--

LOCK TABLES `budget_transaction_journal` WRITE;
/*!40000 ALTER TABLE `budget_transaction_journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_transaction_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budgets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `name` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `order` mediumint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `budgets_user_id_index` (`user_id`),
  KEY `budgets_user_group_id_index` (`user_group_id`),
  CONSTRAINT `budgets_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `budgets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `name` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_user_id_index` (`user_id`),
  KEY `categories_user_group_id_index` (`user_group_id`),
  CONSTRAINT `categories_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_transaction`
--

DROP TABLE IF EXISTS `category_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_transaction` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `transaction_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_transaction_category_id_foreign` (`category_id`),
  KEY `category_transaction_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `category_transaction_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_transaction_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_transaction`
--

LOCK TABLES `category_transaction` WRITE;
/*!40000 ALTER TABLE `category_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_transaction_journal`
--

DROP TABLE IF EXISTS `category_transaction_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_transaction_journal` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `transaction_journal_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_transaction_journal_category_id_foreign` (`category_id`),
  KEY `category_transaction_journal_transaction_journal_id_index` (`transaction_journal_id`),
  CONSTRAINT `category_transaction_journal_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_transaction_journal_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_transaction_journal`
--

LOCK TABLES `category_transaction_journal` WRITE;
/*!40000 ALTER TABLE `category_transaction_journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_transaction_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuration` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:36:35',NULL,'db_version','26'),(2,'2025-10-04 19:35:12','2025-10-04 19:35:12',NULL,'installation_id','\"3e83c4aa-9a15-479e-be18-d7ff2d8b01f0\"'),(3,'2025-10-04 19:35:12','2025-10-04 19:35:12',NULL,'is_demo_site','false'),(4,'2025-10-04 19:36:35','2025-10-04 19:36:35',NULL,'ff3_version','\"6.4.0\"'),(5,'2025-10-04 19:38:08','2025-10-04 19:38:08',NULL,'oauth_private_key','\"eyJpdiI6IlA2QTZEcXd2OW1nSUtLcWYySkFPdGc9PSIsInZhbHVlIjoiK202cytxMjBmV2gzWDgrakhTRnV4clYxbGc0Y2Fpeng0S3JnZmp4WDc3ZVR4UnpiTDNXd1NiUUZHOEltVTBpZGZpZmNhVU9zcVB1RDRmSjFLNkIyejBIOThBbnR1VmRCamFZb3dwZHZ3R3h6YnR1czVyeGloNjRZVW4wR003WTZrWmJTbDVZOTgyemo0Q2dRajlLRVY1N2lzY1lRVTczbHE1d3gyVGN3Qkdrc0dsWjhIUVhFdHhIRVdpQU9xSkloMHljbmhobFUrRjNINytmZkVKL0tZRmNxSElXcVA1ejBUWlkzVTVsU2kvK2JqOGZzWVdTZGc3YzVuK01DWjVreTJ4UUpqSGFTR1hLdCthamsrNjIxdmkwbldXT2h2QjREVW92eWhXczZHWDJCTGthdjhWajJBaHBxbEdhTTErOXFxd3RzOFgyd0hlNWNJK3E3NXl1dHltY0tYVGJPMFEwY2dkMmYxVTViTkN1cVBKcHFrQ0kxdklqa3RWWU5PdnJWczFyMWw4NklMVk1ZWUNXeEhONmJ3eHhQaGFpaFBtMFliUGNwdDU0anFOdlhLRjNGVEtyUmNKVjFNdi91NkZtU3RycnkvSU52Q0ZrazRwUk5JNzc1RmtDUlMvS1hwZU5SL015R3UvVjBRdkdmTzExdFA4b3V6NjFJd1RZMW5KWDZYRTMyUlJ6cUVINWxMeUIvbTRNcGlMVStLbUpaaDJPeHZmT1F1VzBTb1RYZjF2OGlPNVVxSCt1bGh3aXVXcHZhSE5aMTFlV0FpU2gxYWN4Tzkwck1PcURtYXpVWlNYRjdLM2UrcnJoM3dXYlNUYWQ3RDVyeVo2VE1WZWNtS01ZWEFmaHB5WnRDQk50TEt3T0h2L3V2cU5rOW9wenZZZU5wMVNsVUtpN1VQVktLT2J6TUI5a0lOSE1jNWU3bk5BeTF1WnYzc1AxQ1Rldi9RaFBVcCtXMGxnWGhCcjBGZkxYVGJtd2hkWWZ0cFcrcXNXWkhsbGh2SDVpQ2tSYzFhTFlDMFNIcTVoNlRJZ2FDREMzSkdSTTBidUZJTFFUcDNNZXdMK2kxcHVKSjhLejR2M2YxaG5SNnpOOWNCMllpeFJDUHpoUlV5c0tCdmxtb0RaTkdFVEUxV0EvYjNjTmZlQTJIK0c4VWhlcmprODhxOS91eW1rUXJOMUxnSmdPUWZxbWpQK1QrMXB6bzR6YU9oYmlkMEl4M2ZvK2k0NUNTOGtxUFhyWS9FT0E1RVZkaWVlZEtPUWpBb0pNMHBDdlB2YjRWbzlscEE0QUFJalJLaFU1SUtwbXplTWxIQ1FpUURRUlZUMTZYcjBiZk1sM2svTWNJeFNJYVRjRjkyeWFra3ZvcFg4OUlOSXlXazh3T0lqRnMvWTh2TVJVZnVVdnJ0UEJSM1Bpb2hGUTBKbmZCaFM2UWxoK2ZxNmR6OUJveGVrK0xYcm04a3d0dFpGajBOUXM5RTFKSkRxVHR2eEEzV2RZY2RDYnZKRmE4SzlkU284dVZ6UDBIeHBWUjBmR2drYkRybDRlcWwvSTlJY1lKODdJOWFUTE1CMzFySk5xem45aTBwZ2ZqUnN0aXpZbEh5Z0UxVnhSeDAxaU90V2pBS29UR0VFVmdjOTJzTGhDRm90UnFyYmJUSHpMVGZSRlhsSTNsNFpCOVIxY3NGN0FBZjBFNG5uNXVhZDZPSWhZY1B2R1NwNXJIdzAvVjY0WlBwTUh6ZXZ1NWVyZGVlYkFjODMwdGNFNXlmM2lMR0IzYWZ1V1pSVGh6Vk9zYkppRHhkeTNldnhWOEJ2RFZ0ZXBRS2gvcVhkeEZRaC9Tc2ZJck81aUpranRaSUZIaERPMHFod2h4OWt2UUQ0SkZHRGJkcDRoSjV0VmpRWVRhL0dxZ2dnMzBtR2U4WEZSZkJmL3F0T2xIOEF6RWVIc0VwSW1ia3RFelhPL2x3RzE3NjNxVGRkVWlBblBWSmNJaXJHTnZCVXVaTFp3dzZybWN1ZVZuNnNENS95MXo5T0JBb2RvT1BIejlvRGtuS1dtTW5EdmpvcWtOdGN3YitKN25Ib1lMMDdveU03eVR5WW9UVmNqMzFqZjVjODN1ODFiQWhYTndudGFLWXc0U21yWEdwRVo3VkF5ZHNZK0hkbTBVUnFZc25tTjczclNrSkUvK2J5U1BVaU9Pb0ZGSXBNS2VvRy9kYjVrQi9Ba3NzWTdpUUFMemtOdUpPcElmVk9BZ1ZVU2xlYS9GOHRkYVRJSzRTalFIb0VrT0I3OVZZSDNJLzVFNlVXL09ZdjR0NHJ4ak1qSUtuZjkvZkFuMEtpaFFRLzJNNDZyS3N6U1dkeC9tYklzYVNNaU9RemhUeDlCNUYwTnpZNHJSWW5JZ3BYNDMzc09RdGM4YWV1YW8xc0F0elRjQ1BJQ1RhM3dVT0gvNnVLbkNHbTVnTUt5VFNubVh1eUNYdHpic0QvbTF1cElpN2ZXMmQ5bmMvaDNWbVprditHWkFUcUVweXVkem0vS2JxZXJqaUl3Z1RnSnNRSWdMclAvRXZObkt1a0dMT0tJdW4xQ1pzSlk4dlJpRUs0UzU5RHM4V3ZBSlJadHErczR2TU42b1lxcy9mbTgyYjRaK3dCM2NRcDRqVFJQbGVoWTNvL0Z4Y2dxbVJlVGFYNHI0S1FOQysrV2plREt2c3RmTjFaV0VSZmtCRUgxNENqd3RTTWhwYnhIN2VxY0FxOXNwQnJ5ZDJhVnJrMDZ6bU1QeXB6ZXhSNHZTRERzREtUNGljTnFoanA1ZXZFT0trMDcxeTM1VzVBWXQ3V0k5d0tnME1QWEtQekNoRUpKa3dKRFVxZzBQM25ub2I1aGwybzlKVFo3bVVFM1ltNkJsaE16QllGQTh3RkRmeHRLaTdka2EyaXdWUFNpckVTakc5YWRGV2F4OHBtUVBIQ3kzVjYva1lScGpXcEhMWXc2bTM0cElpSDk5anN1Zkp0bk1VTjBzZHd3ZjZ2b3RxcXY2ejg1ZUc4MFZMaE90NzMrYlFCNHBkanhNbitVLzY1Skx2dmFvUlJjZ1hXelozVzRqcHJoK2pCZ2pZaEZWYWhXQ0JsdTZkQi9YWDdldXM1N1dYczdzN1l2RVBUVm5NUGJ0cnM2ZkR0MTBoUHdyZHFueU44RUhoOElFWEsvZDJIb0FwRlNaeE1GUUZLaGVWOWJHdFc0QTRRZm16cXd1RndyVzNSWWVYVTlXcEQrUXljb2IxWEVwb0RiNCtMU1VtUmZTUW8yM1JwWWE1VlBDcEk4d05zZjlPT01GU2xhVlpwWURSMkZVL05USUJ2dklZSmRLbWhXRHowRFVPdGoxeEIzZUZEY1pBUDFwRlhZeUlEZC9pNEpnc2hOR01uSVV3bHhGWjJBS0RYRDRWMG0ydW1nTjNOQkFaeHZvb0lnMUtLTTBzZG9PemxXSTJCOUpUb2JzQjMyVTdpRFU2V25iZ1F5dnRjR2FKcUZiT0dkVTVreTRuTlU3T3QzWVBUOXA5Rmw2dmNsVktBSCtIcHZxSnBEcWpwczNKUmQ5bjZkZlZsZlA0WlVMclFMejdaLzlxd0txaWFiWHQzTThZcVFIUUk1blZ6c3VkVWhNL0JYbW14amFvMU93cWYwbHNrWjhXZEtpN0xZd04zcDZzREU4Q0hCMTIxdFpzNDNYMFpKUEhVdXVTU0VOcnVKUTJkaW0yWExkTDBmOEpKRmpKbHhzbmZ1MTdZOVdxTzN1aFo4eGVGWEJOdi9OZzA5YmQ4OFZGaENTL0dCRkhxaU1YOFg3dEJJbDRGeXJtWWNBQktGTmhZZm5CUitpR0I0T0trcDdMTnpCbU5tT3kzQzROOHV0akk0bWEvbHZua0pqNHF1MjZYNGJpRlU1Z29qSHcvcFlsWlRQa3VHRmhXNHErYkZ4b05FSGVlZmg5dHZwaVA0NDluVWtpZk5zUysvcjJSY04vdCt6L0F2ekxLM01tcFhjZUxCaVB6cE9BV1czVXlSc0VUdUN1L2hvNnRQSHVhYWQ3ZG1RSFFHSjdqcld3UWxkK1h1bUJEaUNTYXlHU0gvVWIvcTBudTBjRzh1M3ZWQTR1K1NyQXpRK1pKTnVBOGtHR1lsN0J1SDdlT2VYS25oV3Baa1dMRkRKSUZ2RmFGMm8xME84Ni90aTJRMUM3d1d1YjJFa2t6VGRWUytidUV5VEVuTzRaYjNHQ1VDTXNCOG1jS011ODRRZEZ1SUJSUkNFWkJpdnc5RjdIN0xIeTRmWEFlTkpKNTFRWUthd1FGM1p0SDN4NzNKSVJKSWN4bDB6YWlPRThoSWgvNndmWnhBS3JoWVB5MW02VEVRenpvcE9rTWdIMkUrb3NSRFZ4RWZrTkxsWGpxZVRwb1BBSWxuandvc005RTlDT3QxOE9rR1dYYjNEMnhMZkx5S25IZzg2SG9QK0czVmFpNGZieTU1eHVzbXRYRXhyV09YZ2oyQ1Y1eENZYStwTStSV1RFT0E0VnkwYjFjbzdGU0VObllPQTNmby9va1drY2RaQUc5Q3dVY2w3VUJqb013cHl0emxFa1Z1dlJkc1FkNWVDTjJjQkFiOTIvcGNsVTJWZjBHRTBaRVJwZkY3dzcwbXVhRkFONldZTFovbUVIUXRmQldneWFCU09yTGFNMkc1OXN0ck5iWjB5dG9Rb0E1KzlNTldGME5DcC9JVklDanpOREVkc1ViNjVRWm0wUlk5NUh5anZSUkRXMENDRWdqdytUeGxLUEZnVnBSaG1EYWxuNUZtQnZ3dVZGSWN1c1NvdkMxZlMvRWJhV2gwbytlS3g2SUF4U3dUL0Y2dGpXdGZFS0ZmL01rOEdmdkd6SkFydnFVaWlOc0xENE1tb1lQMWVsSG9tdGM4Z3pxOERrelhoRXRwTXA4NktoazhIL09UWHNKTVRHSG1aeGs5TEhLRHk5QWI4eVE3UHIvc3dUaTFlbGpabkxJZ2R5WVZsUlRMZHdSbTJ3T2xNY3BZNUlJeHFkREY2Nys4c2Rwb2dVM0Q5RE8vUklFZWlvQUVhdnRnYm90bTE3MFVoSDNxcHc3Nko1N211aFZNNU5yMGVncm1jRlA5cE5tYmk1ejd1NDI3eGFZdlErMnlkZ0doUVh5c1hXbFZGSmEyRHVWV1kxOHhwV2d3dnJHMzhWcHk3SHY5WnVZaUI1Ri8xUzgvZFhUclcyTmZVSk4wNi9lYXczRXh6OE5tNFpQWW5ITFdraTFnanRmTkVaeXg0Ty84NjJxZWFrTTYxWXRXa2xvUU9UUUM5NTczUnVLK0RiV2lKUkVycHhCRHRWTkJTVDZQa1p2QXpNZVNOa3I1TnBnc1VPRkVqc3ZsSzlneUh1ejJnOXVXUXZURFBEYWxWci9LUHFoZUtVUkpWUFFjZVp0SnRGMUlXZnlWTUF1azE2dFc4SXMxSy96aERqU3JVWjAvdEF4TElxbk5WQWttb29vUG9MVmhveFpzbW5nWVpqV0t5TUtoYm1GOFVqVHlWZG8rd2JrNTBEZjdKWTd6Nk1VTUF4VTdHVU5QMjdIOEJ2MFpIRDA5K0VZa3RPSEtzVjA5bWlWZjM3c0hqZURGQ3NpT1ZGQ0NqcjhhbVBYZ29iOEpqSFRKa25NWDAwa0MrOGhCYlVDcUNLMWNob3l0Y1pkNFZpNnl3MEl5NG1oMXdrUmhrQjdXOHBHZ3V2bEx0Nk5KajZWWGhEUnRkRmo2ay8xMEFIb0o2eG1vWS8yYmRLeHBKUmtJRnhmOEhSU3hwRWw1cVNabzF2dDEwVWtTeU5JTTFFbVBqcXlZcDVvWVY0eld2QXRoN3hiZi9vSlFJZUpNdmt3MDRDREdoRnBMQ21KMXg0Z040QTUrYWJnd1g3WVVBRXhZWTZQWkhUNTVFWnRaWjF5Mk42Tzc3TWkySjJnaGo4TUQxREVrblBZUnJ2VzJLbkRyMGVLSGk0K2pkRTlUYXg2Zz0iLCJtYWMiOiJjZTUyMGIzNmYwZTI0NjQyNGM3ZDU2YmM3MDhjYjdjMDMwNTY0ZDA0Y2ZmZDgwMWE4Y2M1NzZlNDVmYmMyOTVkIiwidGFnIjoiIn0=\"'),(6,'2025-10-04 19:38:08','2025-10-04 19:38:08',NULL,'oauth_public_key','\"eyJpdiI6InV3SXhwZExJZkU4MG4xTHNyU3BoQ1E9PSIsInZhbHVlIjoiWnZkVnBWQnBCVGR3amo5V3pBL1E1NDhSaDFDVG5YN1QzQVFYakdhTC9GSlhXOWdnY281V1llaXowbFBHWmFOeWJHWVU2UTNnVXhzMC9Gc3VZWXBkTjJxcWJjbjN5dk1hSVJXaEx0aTZDUys2RTQ2TCtHWS9oaE9aNEY4K056VHlrOWw1ZWpyZUxwRXp0ZFRDZFlEZHd6UUJWUHhKc3FIdHlQbGExNzlGZVVVYzNURHpVRXh3cHJ0QkpSaUVpK2l4cTRMT09jc2NJTTNxWEFCb3JXdEl4V3FIcnJ4QkhvQ3ByVTNzb2daS0tlUUYyQ1VZaS83cVJsVG1IVjhMWjMyQVJYMlYrczZrSFUrb2Y4Q1lvTE5ra1JvWXZzK091eWNucEFOSXNpWDROYlZtSUJwTmRkOUozK1dIRi80am1qWFN0dTZEUDNSZXlWUktQRFJycFI2SGNLZnRXUHB1VEV3YUJ6NDhjTG9KaVZpcUxlWWxIRjI0dHoxR0hCbHlwMDZldS9YUzZza3FSNUxXbkJ5TlNEdGNSUU1YUmJCbHFXTHFEOEEzVUJBbldwS1V2VWhoa0huK01KZTU0M1EzMStFcmJKTGlvU1VNYWNvdFpDNFdMSUxhVnN4dVptRzBXMlZwSm9ZRFhMdkxHT2YzQ0xHbkM3a0Z3dXlvRHJKU0ROMTJuaUd0SytHU3VUQklsMUhXQXRQQndSZCtBNGZORDJpWlE5MEdodThDTk51bnJMZ3RJdzVCSlpkYTMxZ0xwRkV3bWVqa1NOS0lOWHZzTUJTMGp5eG95S296aFVLV2tVSU9ETEtISGRNcko3Nk5CWjRSSmQraXhTcjFCSVk4dHVRZGZ0UThEOEJ6TkgrakswM3pJVVNIVk1FcGswQTlTMllyVkQrWVdjQ2hGTUhxRktVL0RKQUJsWlZWN0NFeGxxWXIwM2VlamgvbllVcmdkd0F2YVBObHVWSlN4QkYyU1FHeTdqTmlrTzZSNHRmT09KaTNTZmN1bTNCMHppUHdRaGZRQjh4ek9WZUVGUExNVGdlRkJhMlBnZ0M0RmR2elI0RllLMi8rbTE4aWhCdXFEYjJNa3dwMURxYm5lSlp4YzRncW1tVVFzR2lzRDhYRytHSFovVlBNcWxzc0d5SFpBOVNQZm01YWJXNWlLbVoyVGZ5SXdONUxscDFyZjVrSnRJbEVjOGo0YkxHcWtOSmIxRzVJMWZOMnZRZzdUZ1JUZTE4ejlBWjFzenUzQW91ekw1VUpsUUQwZnJsTXZobkNEWG5qZ0pNZjVOWnlQcUlNbU02QlhPWWx3YnJQZ0NRSmNQb2xiVkRXNXcrem1KK1FIZDE4Uk1OTU5pcUl5RnlZQ2ZmZnZlelhHWEk3b1kyalpmL0U0akNXdzN0ODV5S1h3a25YYWc5Y2Z4TDhrZVhXY0l1WWJjcmJJclVnVlp6aDJwK2lvUDJVbERKZGdhTUx6dFZtRVVjZE1RPT0iLCJtYWMiOiJhN2EyMWYxMjk2NTE3MjI3MjVjNWEyNWEyOTViMGY0ZTE0ODE4Nzc3OWMxMTMyZDFiNWVlNWU0MDBiNjdmMjU0IiwidGFnIjoiIn0=\"'),(7,'2025-10-04 19:38:08','2025-10-04 19:38:08',NULL,'single_user_mode','true'),(8,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,'notification_user_new_reg','true'),(9,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,'notification_admin_new_reg','true'),(10,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,'slack_webhook_url','\"\"'),(11,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,'pushover_app_token','\"\"'),(12,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,'pushover_user_token','\"\"'),(13,'2025-10-04 19:48:48','2025-10-04 19:48:48',NULL,'utc','false'),(14,'2025-10-04 19:48:49','2025-10-04 19:48:49',NULL,'permission_update_check','-1'),(15,'2025-10-04 19:48:49','2025-10-04 19:48:49',NULL,'last_update_warning','1759632529');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_exchange_rates`
--

DROP TABLE IF EXISTS `currency_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_exchange_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `from_currency_id` int unsigned NOT NULL,
  `to_currency_id` int unsigned NOT NULL,
  `date` date NOT NULL,
  `date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(32,12) NOT NULL,
  `user_rate` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency_exchange_rates_user_id_foreign` (`user_id`),
  KEY `currency_exchange_rates_from_currency_id_foreign` (`from_currency_id`),
  KEY `currency_exchange_rates_to_currency_id_foreign` (`to_currency_id`),
  KEY `cer_to_ugi` (`user_group_id`),
  CONSTRAINT `cer_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `currency_exchange_rates_from_currency_id_foreign` FOREIGN KEY (`from_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `currency_exchange_rates_to_currency_id_foreign` FOREIGN KEY (`to_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `currency_exchange_rates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_exchange_rates`
--

LOCK TABLES `currency_exchange_rates` WRITE;
/*!40000 ALTER TABLE `currency_exchange_rates` DISABLE KEYS */;
INSERT INTO `currency_exchange_rates` VALUES (1,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,1,'2025-04-15','America/Los_Angeles',1.000000000000,NULL),(2,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,2,'2025-04-15','America/Los_Angeles',410.797980000000,NULL),(3,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,3,'2025-04-15','America/Los_Angeles',0.860032610000,NULL),(4,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,4,'2025-04-15','America/Los_Angeles',46.867455000000,NULL),(5,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,5,'2025-04-15','America/Los_Angeles',4.280209800000,NULL),(6,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,6,'2025-04-15','America/Los_Angeles',43.180054000000,NULL),(7,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,7,'2025-04-15','America/Los_Angeles',7.459100000000,NULL),(8,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,11,'2025-04-15','America/Los_Angeles',7.464833600000,NULL),(9,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,12,'2025-04-15','America/Los_Angeles',1.134904400000,NULL),(10,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,13,'2025-04-15','America/Los_Angeles',6.645851800000,NULL),(11,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,14,'2025-04-15','America/Los_Angeles',1.575105000000,NULL),(12,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,15,'2025-04-15','America/Los_Angeles',22.805278000000,NULL),(13,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,16,'2025-04-15','America/Los_Angeles',19070.382000000000,NULL),(14,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,17,'2025-04-15','America/Los_Angeles',1.787202000000,NULL),(15,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,18,'2025-04-15','America/Los_Angeles',1.919107800000,NULL),(16,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,19,'2025-04-15','America/Los_Angeles',57.874172000000,NULL),(17,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,20,'2025-04-15','America/Los_Angeles',10.549438000000,NULL),(18,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,21,'2025-04-15','America/Los_Angeles',21.444356000000,NULL),(19,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,22,'2025-04-15','America/Los_Angeles',162.471950000000,NULL),(20,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,23,'2025-04-15','America/Los_Angeles',8.284997700000,NULL),(21,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,25,'2025-04-15','America/Los_Angeles',93.344230000000,NULL),(22,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,26,'2025-04-15','America/Los_Angeles',97.572815000000,NULL),(23,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,27,'2025-04-15','America/Los_Angeles',4.180178600000,NULL),(24,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,28,'2025-04-15','America/Los_Angeles',0.926831260000,NULL),(25,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,29,'2025-04-15','America/Los_Angeles',7.534500000000,NULL),(26,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,8,'2025-04-15','America/Los_Angeles',145.105320000000,NULL),(27,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,9,'2025-04-15','America/Los_Angeles',11.980824000000,NULL),(28,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,10,'2025-04-15','America/Los_Angeles',11.088090000000,NULL),(29,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,30,'2025-04-15','America/Los_Angeles',8.804632200000,NULL),(30,'2025-10-04 19:44:40','2025-10-04 22:05:00',NULL,1,1,1,31,'2025-04-15','America/Los_Angeles',25.092213000000,NULL);
/*!40000 ALTER TABLE `currency_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_journals`
--

DROP TABLE IF EXISTS `group_journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_journals` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_group_id` int unsigned NOT NULL,
  `transaction_journal_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_in_group` (`transaction_group_id`,`transaction_journal_id`),
  KEY `group_journals_transaction_journal_id_foreign` (`transaction_journal_id`),
  CONSTRAINT `group_journals_transaction_group_id_foreign` FOREIGN KEY (`transaction_group_id`) REFERENCES `transaction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_journals_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_journals`
--

LOCK TABLES `group_journals` WRITE;
/*!40000 ALTER TABLE `group_journals` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_memberships`
--

DROP TABLE IF EXISTS `group_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_memberships` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned NOT NULL,
  `user_role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_memberships_user_id_user_group_id_user_role_id_unique` (`user_id`,`user_group_id`,`user_role_id`),
  KEY `group_memberships_user_group_id_foreign` (`user_group_id`),
  KEY `group_memberships_user_role_id_foreign` (`user_role_id`),
  CONSTRAINT `group_memberships_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `group_memberships_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `group_memberships_user_role_id_foreign` FOREIGN KEY (`user_role_id`) REFERENCES `user_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_memberships`
--

LOCK TABLES `group_memberships` WRITE;
/*!40000 ALTER TABLE `group_memberships` DISABLE KEYS */;
INSERT INTO `group_memberships` VALUES (1,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,1,1,21);
/*!40000 ALTER TABLE `group_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invited_users`
--

DROP TABLE IF EXISTS `invited_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invited_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invite_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime NOT NULL,
  `expires_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redeemed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invited_users_user_id_foreign` (`user_id`),
  CONSTRAINT `invited_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invited_users`
--

LOCK TABLES `invited_users` WRITE;
/*!40000 ALTER TABLE `invited_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `invited_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_links`
--

DROP TABLE IF EXISTS `journal_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_links` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `link_type_id` int unsigned NOT NULL,
  `source_id` int unsigned NOT NULL,
  `destination_id` int unsigned NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `journal_links_link_type_id_source_id_destination_id_unique` (`link_type_id`,`source_id`,`destination_id`),
  KEY `journal_links_source_id_foreign` (`source_id`),
  KEY `journal_links_destination_id_foreign` (`destination_id`),
  CONSTRAINT `journal_links_destination_id_foreign` FOREIGN KEY (`destination_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_links_link_type_id_foreign` FOREIGN KEY (`link_type_id`) REFERENCES `link_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_links_source_id_foreign` FOREIGN KEY (`source_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_links`
--

LOCK TABLES `journal_links` WRITE;
/*!40000 ALTER TABLE `journal_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_meta`
--

DROP TABLE IF EXISTS `journal_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_meta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `transaction_journal_id` int unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `journal_meta_transaction_journal_id_index` (`transaction_journal_id`),
  KEY `journal_meta_name_index` (`name`),
  CONSTRAINT `journal_meta_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_meta`
--

LOCK TABLES `journal_meta` WRITE;
/*!40000 ALTER TABLE `journal_meta` DISABLE KEYS */;
INSERT INTO `journal_meta` VALUES (1,'2025-10-04 19:48:48','2025-10-04 19:48:48',1,'import_hash_v2','\"9a83b1a20e9adf4d0bbd7713f4f3a5ef5ffcd555e0f491bdc229cc2bcf60df26\"','d50de856e73f44898a91b57a719e553f7d64b62fb3b5f935cd7ac9b12a658105',NULL),(2,'2025-10-04 19:48:48','2025-10-04 19:48:48',2,'import_hash_v2','\"7a87ba17731b07c76299bf6559d8620f2f871cfcaed4633e940b12d781b9dc66\"','90085a1f8b0cb03fcd17cb61573e5aaaccb9452dcd2ec75dd9ab90da7abfa1bb',NULL);
/*!40000 ALTER TABLE `journal_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_types`
--

DROP TABLE IF EXISTS `link_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `link_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `outward` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inward` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `editable` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `link_types_name_outward_inward_unique` (`name`,`outward`,`inward`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_types`
--

LOCK TABLES `link_types` WRITE;
/*!40000 ALTER TABLE `link_types` DISABLE KEYS */;
INSERT INTO `link_types` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Related','relates to','relates to',0),(2,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Refund','(partially) refunds','is (partially) refunded by',0),(3,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Paid','(partially) pays for','is (partially) paid for by',0),(4,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Reimbursement','(partially) reimburses','is (partially) reimbursed by',0);
/*!40000 ALTER TABLE `link_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `locatable_id` int unsigned NOT NULL,
  `locatable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(12,8) DEFAULT NULL,
  `longitude` decimal(12,8) DEFAULT NULL,
  `zoom_level` smallint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2016_06_16_000000_create_support_tables',1),(2,'2016_06_16_000001_create_users_table',1),(3,'2016_06_16_000002_create_main_tables',1),(4,'2016_08_25_091522_changes_for_3101',1),(5,'2016_09_12_121359_fix_nullables',1),(6,'2016_10_09_150037_expand_transactions_table',1),(7,'2016_10_22_075804_changes_for_v410',1),(8,'2016_11_24_210552_changes_for_v420',1),(9,'2016_12_22_150431_changes_for_v430',1),(10,'2016_12_28_203205_changes_for_v431',1),(11,'2017_04_13_163623_changes_for_v440',1),(12,'2017_06_02_105232_changes_for_v450',1),(13,'2017_08_20_062014_changes_for_v470',1),(14,'2017_11_04_170844_changes_for_v470a',1),(15,'2018_01_01_000001_create_oauth_auth_codes_table',1),(16,'2018_01_01_000002_create_oauth_access_tokens_table',1),(17,'2018_01_01_000003_create_oauth_refresh_tokens_table',1),(18,'2018_01_01_000004_create_oauth_clients_table',1),(19,'2018_01_01_000005_create_oauth_personal_access_clients_table',1),(20,'2018_03_19_141348_changes_for_v472',1),(21,'2018_04_07_210913_changes_for_v473',1),(22,'2018_04_29_174524_changes_for_v474',1),(23,'2018_06_08_200526_changes_for_v475',1),(24,'2018_09_05_195147_changes_for_v477',1),(25,'2018_11_06_172532_changes_for_v479',1),(26,'2019_01_28_193833_changes_for_v4710',1),(27,'2019_02_05_055516_changes_for_v4711',1),(28,'2019_02_11_170529_changes_for_v4712',1),(29,'2019_03_11_223700_fix_ldap_configuration',1),(30,'2019_03_22_183214_changes_for_v480',1),(31,'2019_11_30_000000_create_2fa_token_table',1),(32,'2019_12_28_191351_make_locations_table',1),(33,'2020_03_13_201950_changes_for_v520',1),(34,'2020_06_07_063612_changes_for_v530',1),(35,'2020_06_30_202620_changes_for_v530a',1),(36,'2020_07_24_162820_changes_for_v540',1),(37,'2020_11_12_070604_changes_for_v550',1),(38,'2021_03_12_061213_changes_for_v550b2',1),(39,'2021_05_09_064644_add_ldap_columns_to_users_table',1),(40,'2021_05_13_053836_extend_currency_info',1),(41,'2021_07_05_193044_drop_tele_table',1),(42,'2021_08_28_073733_user_groups',1),(43,'2021_12_27_000001_create_local_personal_access_tokens_table',1),(44,'2022_08_21_104626_add_user_groups',1),(45,'2022_09_18_123911_create_notifications_table',1),(46,'2022_10_01_074908_invited_users',1),(47,'2022_10_01_210238_audit_log_entries',1),(48,'2023_08_11_192521_upgrade_og_table',1),(49,'2023_10_21_113213_add_currency_pivot_tables',1),(50,'2024_03_03_174645_add_indices',1),(51,'2024_04_01_174351_expand_preferences_table',1),(52,'2024_05_12_060551_create_account_balance_table',1),(53,'2024_07_28_145631_add_running_balance',1),(54,'2024_11_05_062108_add_date_tz_columns',1),(55,'2024_11_30_075826_multi_piggy',1),(56,'2024_12_19_061003_add_native_amount_column',1),(57,'2025_07_10_065736_rename_tag_mode',1),(58,'2025_08_19_180459_create_webhook_details_tables',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `noteable_id` int unsigned NOT NULL,
  `noteable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `client_id` int NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_groupables`
--

DROP TABLE IF EXISTS `object_groupables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_groupables` (
  `object_group_id` int NOT NULL,
  `object_groupable_id` int unsigned NOT NULL,
  `object_groupable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_groupables`
--

LOCK TABLES `object_groupables` WRITE;
/*!40000 ALTER TABLE `object_groupables` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_groupables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_groups`
--

DROP TABLE IF EXISTS `object_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` mediumint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `object_groups_user_id_foreign` (`user_id`),
  KEY `object_groups_to_ugi` (`user_group_id`),
  CONSTRAINT `object_groups_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `object_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_groups`
--

LOCK TABLES `object_groups` WRITE;
/*!40000 ALTER TABLE `object_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_role` (
  `permission_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piggy_bank_events`
--

DROP TABLE IF EXISTS `piggy_bank_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `piggy_bank_events` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `piggy_bank_id` int unsigned NOT NULL,
  `transaction_journal_id` int unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(32,12) NOT NULL,
  `native_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `piggy_bank_events_piggy_bank_id_foreign` (`piggy_bank_id`),
  KEY `piggy_bank_events_transaction_journal_id_foreign` (`transaction_journal_id`),
  CONSTRAINT `piggy_bank_events_piggy_bank_id_foreign` FOREIGN KEY (`piggy_bank_id`) REFERENCES `piggy_banks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `piggy_bank_events_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piggy_bank_events`
--

LOCK TABLES `piggy_bank_events` WRITE;
/*!40000 ALTER TABLE `piggy_bank_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `piggy_bank_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piggy_bank_repetitions`
--

DROP TABLE IF EXISTS `piggy_bank_repetitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `piggy_bank_repetitions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `piggy_bank_id` int unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `start_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_date` date DEFAULT NULL,
  `target_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_amount` decimal(32,12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `piggy_bank_repetitions_piggy_bank_id_foreign` (`piggy_bank_id`),
  CONSTRAINT `piggy_bank_repetitions_piggy_bank_id_foreign` FOREIGN KEY (`piggy_bank_id`) REFERENCES `piggy_banks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piggy_bank_repetitions`
--

LOCK TABLES `piggy_bank_repetitions` WRITE;
/*!40000 ALTER TABLE `piggy_bank_repetitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `piggy_bank_repetitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piggy_banks`
--

DROP TABLE IF EXISTS `piggy_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `piggy_banks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `account_id` int unsigned DEFAULT NULL,
  `transaction_currency_id` int unsigned DEFAULT NULL,
  `name` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_amount` decimal(32,12) NOT NULL,
  `start_date` date DEFAULT NULL,
  `start_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_date` date DEFAULT NULL,
  `target_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `encrypted` tinyint(1) NOT NULL DEFAULT '1',
  `native_target_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unique_currency` (`transaction_currency_id`),
  KEY `piggy_banks_account_id_foreign` (`account_id`),
  CONSTRAINT `piggy_banks_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `unique_currency` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piggy_banks`
--

LOCK TABLES `piggy_banks` WRITE;
/*!40000 ALTER TABLE `piggy_banks` DISABLE KEYS */;
/*!40000 ALTER TABLE `piggy_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `name` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `preferences_user_id_foreign` (`user_id`),
  KEY `preferences_to_ugi` (`user_group_id`),
  CONSTRAINT `preferences_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `preferences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES (1,'2025-10-04 19:44:40','2025-10-04 22:05:00',1,1,'viewRange','\"1M\"'),(2,'2025-10-04 19:44:41','2025-10-04 22:05:00',1,1,'language','\"en_US\"'),(3,'2025-10-04 19:44:41','2025-10-04 22:05:00',1,1,'locale','\"equal\"'),(4,'2025-10-04 19:44:41','2025-10-04 22:05:00',1,1,'lastActivity','\"0.00034800 1759632529\"'),(5,'2025-10-04 19:44:41','2025-10-04 22:05:00',1,1,'list-length','10'),(6,'2025-10-04 19:44:41','2025-10-04 22:05:00',1,1,'darkMode','\"browser\"'),(7,'2025-10-04 19:44:41','2025-10-04 22:05:00',1,1,'convert_to_primary','false'),(8,'2025-10-04 19:48:48','2025-10-04 22:05:00',1,1,'frontpageAccounts','[1,3,5]'),(9,'2025-10-04 19:48:48','2025-10-04 22:05:00',1,1,'transaction_journal_optional_fields','{\"interest_date\":true,\"book_date\":false,\"process_date\":false,\"due_date\":false,\"payment_date\":false,\"invoice_date\":false,\"internal_reference\":false,\"notes\":true,\"attachments\":true}'),(10,'2025-10-04 19:48:49','2025-10-04 22:05:00',1,1,'shown_demo_index','false'),(11,'2025-10-04 19:49:13','2025-10-04 22:05:00',1,1,'shown_demo_budgets_index','false'),(12,'2025-10-04 19:49:25','2025-10-04 22:05:00',1,1,'shown_demo_reports_index','false'),(13,'2025-10-04 19:49:25','2025-10-04 22:05:00',1,1,'customFiscalYear','false'),(14,'2025-10-04 19:49:52','2025-10-04 22:05:00',1,1,'shown_demo_piggy-banks_index','false'),(15,'2025-10-04 21:55:52','2025-10-04 22:05:00',1,1,'login_ip_history','[{\"ip\":\"192.168.0.1\",\"time\":\"2025-10-04 21:55:52\",\"notified\":true}]'),(16,'2025-10-04 21:55:52','2025-10-04 22:05:00',1,1,'notification_user_login','true'),(17,'2025-10-04 21:55:52','2025-10-04 22:05:00',1,1,'slack_webhook_url','\"\"'),(18,'2025-10-04 21:55:52','2025-10-04 22:05:00',1,1,'pushover_app_token','\"\"'),(19,'2025-10-04 21:55:52','2025-10-04 22:05:00',1,1,'pushover_user_token','\"\"'),(20,'2025-10-04 22:05:00','2025-10-04 22:05:00',1,NULL,'access_token','\"eda4ff18733715403b879503159087f4\"');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences`
--

DROP TABLE IF EXISTS `recurrences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recurrences` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `transaction_type_id` int unsigned NOT NULL,
  `title` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_date` date NOT NULL,
  `first_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_until_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latest_date` date DEFAULT NULL,
  `latest_date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repetitions` smallint unsigned NOT NULL,
  `apply_rules` tinyint(1) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `recurrences_user_id_foreign` (`user_id`),
  KEY `recurrences_transaction_type_id_foreign` (`transaction_type_id`),
  KEY `recurrences_to_ugi` (`user_group_id`),
  CONSTRAINT `recurrences_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recurrences_transaction_type_id_foreign` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences`
--

LOCK TABLES `recurrences` WRITE;
/*!40000 ALTER TABLE `recurrences` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_meta`
--

DROP TABLE IF EXISTS `recurrences_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recurrences_meta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `recurrence_id` int unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recurrences_meta_recurrence_id_foreign` (`recurrence_id`),
  CONSTRAINT `recurrences_meta_recurrence_id_foreign` FOREIGN KEY (`recurrence_id`) REFERENCES `recurrences` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_meta`
--

LOCK TABLES `recurrences_meta` WRITE;
/*!40000 ALTER TABLE `recurrences_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_repetitions`
--

DROP TABLE IF EXISTS `recurrences_repetitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recurrences_repetitions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `recurrence_id` int unsigned NOT NULL,
  `repetition_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repetition_moment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repetition_skip` smallint unsigned NOT NULL,
  `weekend` smallint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recurrences_repetitions_recurrence_id_foreign` (`recurrence_id`),
  CONSTRAINT `recurrences_repetitions_recurrence_id_foreign` FOREIGN KEY (`recurrence_id`) REFERENCES `recurrences` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_repetitions`
--

LOCK TABLES `recurrences_repetitions` WRITE;
/*!40000 ALTER TABLE `recurrences_repetitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_repetitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_transactions`
--

DROP TABLE IF EXISTS `recurrences_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recurrences_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `recurrence_id` int unsigned NOT NULL,
  `transaction_currency_id` int unsigned NOT NULL,
  `transaction_type_id` int unsigned DEFAULT NULL,
  `foreign_currency_id` int unsigned DEFAULT NULL,
  `source_id` int unsigned NOT NULL,
  `destination_id` int unsigned NOT NULL,
  `amount` decimal(32,12) NOT NULL,
  `foreign_amount` decimal(32,12) DEFAULT NULL,
  `description` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recurrences_transactions_recurrence_id_foreign` (`recurrence_id`),
  KEY `recurrences_transactions_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `recurrences_transactions_foreign_currency_id_foreign` (`foreign_currency_id`),
  KEY `recurrences_transactions_source_id_foreign` (`source_id`),
  KEY `recurrences_transactions_destination_id_foreign` (`destination_id`),
  KEY `type_foreign` (`transaction_type_id`),
  CONSTRAINT `recurrences_transactions_destination_id_foreign` FOREIGN KEY (`destination_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_transactions_foreign_currency_id_foreign` FOREIGN KEY (`foreign_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recurrences_transactions_recurrence_id_foreign` FOREIGN KEY (`recurrence_id`) REFERENCES `recurrences` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_transactions_source_id_foreign` FOREIGN KEY (`source_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_transactions_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `type_foreign` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_transactions`
--

LOCK TABLES `recurrences_transactions` WRITE;
/*!40000 ALTER TABLE `recurrences_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `user_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11','owner','Site Owner','User runs this instance of FF3'),(2,'2025-10-04 19:30:11','2025-10-04 19:30:11','demo','Demo User','User is a demo user');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_meta`
--

DROP TABLE IF EXISTS `rt_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rt_meta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `rt_id` int unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rt_meta_rt_id_foreign` (`rt_id`),
  CONSTRAINT `rt_meta_rt_id_foreign` FOREIGN KEY (`rt_id`) REFERENCES `recurrences_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_meta`
--

LOCK TABLES `rt_meta` WRITE;
/*!40000 ALTER TABLE `rt_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_actions`
--

DROP TABLE IF EXISTS `rule_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_actions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rule_id` int unsigned NOT NULL,
  `action_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `stop_processing` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rule_actions_rule_id_foreign` (`rule_id`),
  CONSTRAINT `rule_actions_rule_id_foreign` FOREIGN KEY (`rule_id`) REFERENCES `rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_actions`
--

LOCK TABLES `rule_actions` WRITE;
/*!40000 ALTER TABLE `rule_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_groups`
--

DROP TABLE IF EXISTS `rule_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `stop_processing` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rule_groups_user_id_foreign` (`user_id`),
  KEY `rule_groups_to_ugi` (`user_group_id`),
  CONSTRAINT `rule_groups_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `rule_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_groups`
--

LOCK TABLES `rule_groups` WRITE;
/*!40000 ALTER TABLE `rule_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_triggers`
--

DROP TABLE IF EXISTS `rule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_triggers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rule_id` int unsigned NOT NULL,
  `trigger_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trigger_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `stop_processing` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rule_triggers_rule_id_foreign` (`rule_id`),
  CONSTRAINT `rule_triggers_rule_id_foreign` FOREIGN KEY (`rule_id`) REFERENCES `rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_triggers`
--

LOCK TABLES `rule_triggers` WRITE;
/*!40000 ALTER TABLE `rule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rules`
--

DROP TABLE IF EXISTS `rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `rule_group_id` int unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order` int unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `stop_processing` tinyint(1) NOT NULL DEFAULT '0',
  `strict` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `rules_user_id_foreign` (`user_id`),
  KEY `rules_rule_group_id_foreign` (`rule_group_id`),
  KEY `rules_to_ugi` (`user_group_id`),
  CONSTRAINT `rules_rule_group_id_foreign` FOREIGN KEY (`rule_group_id`) REFERENCES `rule_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rules_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `rules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rules`
--

LOCK TABLES `rules` WRITE;
/*!40000 ALTER TABLE `rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_transaction_journal`
--

DROP TABLE IF EXISTS `tag_transaction_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_transaction_journal` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` int unsigned NOT NULL,
  `transaction_journal_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_transaction_journal_tag_id_transaction_journal_id_unique` (`tag_id`,`transaction_journal_id`),
  KEY `tag_transaction_journal_transaction_journal_id_foreign` (`transaction_journal_id`),
  CONSTRAINT `tag_transaction_journal_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tag_transaction_journal_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_transaction_journal`
--

LOCK TABLES `tag_transaction_journal` WRITE;
/*!40000 ALTER TABLE `tag_transaction_journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_transaction_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `tag` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_mode` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date DEFAULT NULL,
  `date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `latitude` decimal(12,8) DEFAULT NULL,
  `longitude` decimal(12,8) DEFAULT NULL,
  `zoomLevel` smallint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_user_id_foreign` (`user_id`),
  KEY `tags_to_ugi` (`user_group_id`),
  CONSTRAINT `tags_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tags_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_currencies`
--

DROP TABLE IF EXISTS `transaction_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_currencies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `code` varchar(51) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(51) COLLATE utf8mb4_unicode_ci NOT NULL,
  `decimal_places` smallint unsigned NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_currencies_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_currencies`
--

LOCK TABLES `transaction_currencies` WRITE;
/*!40000 ALTER TABLE `transaction_currencies` DISABLE KEYS */;
INSERT INTO `transaction_currencies` VALUES (1,'2025-10-04 19:30:10','2025-10-04 19:48:48',NULL,1,'EUR','Euro','€',2),(2,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'HUF','Hungarian forint','Ft',2),(3,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'GBP','British Pound','£',2),(4,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'UAH','Ukrainian hryvnia','₴',2),(5,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'PLN','Polish złoty','zł',2),(6,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'TRY','Turkish lira','₺',2),(7,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'DKK','Dansk krone','kr.',2),(8,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'ISK','Íslensk króna','kr.',2),(9,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'NOK','Norsk krone','kr.',2),(10,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'SEK','Svensk krona','kr.',2),(11,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'RON','Romanian leu','lei',2),(12,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'USD','US Dollar','$',2),(13,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'BRL','Brazilian real','R$',2),(14,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'CAD','Canadian dollar','C$',2),(15,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'MXN','Mexican peso','MX$',2),(16,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'IDR','Indonesian rupiah','Rp',2),(17,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'AUD','Australian dollar','A$',2),(18,'2025-10-04 19:30:10','2025-10-04 19:30:10',NULL,0,'NZD','New Zealand dollar','NZ$',2),(19,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'EGP','Egyptian pound','E£',2),(20,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'MAD','Moroccan dirham','DH',2),(21,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'ZAR','South African rand','R',2),(22,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'JPY','Japanese yen','¥',0),(23,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'CNY','Chinese yuan','¥',2),(24,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'KRW','South Korean won','₩',2),(25,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'RUB','Russian ruble','₽',2),(26,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'INR','Indian rupee','₹',2),(27,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'ILS','Israeli new shekel','₪',2),(28,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'CHF','Swiss franc','CHF',2),(29,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'HRK','Croatian kuna','kn',2),(30,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'HKD','Hong Kong dollar','HK$',2),(31,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,0,'CZK','Czech koruna','Kč',2);
/*!40000 ALTER TABLE `transaction_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_currency_user`
--

DROP TABLE IF EXISTS `transaction_currency_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_currency_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `transaction_currency_id` int unsigned NOT NULL,
  `user_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_combo` (`user_id`,`transaction_currency_id`),
  KEY `transaction_currency_user_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `transaction_currency_user_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_currency_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_currency_user`
--

LOCK TABLES `transaction_currency_user` WRITE;
/*!40000 ALTER TABLE `transaction_currency_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_currency_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_currency_user_group`
--

DROP TABLE IF EXISTS `transaction_currency_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_currency_user_group` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_group_id` bigint unsigned NOT NULL,
  `transaction_currency_id` int unsigned NOT NULL,
  `group_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_combo_ug` (`user_group_id`,`transaction_currency_id`),
  KEY `transaction_currency_user_group_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `transaction_currency_user_group_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_currency_user_group_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_currency_user_group`
--

LOCK TABLES `transaction_currency_user_group` WRITE;
/*!40000 ALTER TABLE `transaction_currency_user_group` DISABLE KEYS */;
INSERT INTO `transaction_currency_user_group` VALUES (2,'2025-10-04 19:48:48','2025-10-04 19:48:48',1,1,1);
/*!40000 ALTER TABLE `transaction_currency_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_groups`
--

DROP TABLE IF EXISTS `transaction_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `title` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_groups_user_id_index` (`user_id`),
  KEY `transaction_groups_user_group_id_index` (`user_group_id`),
  CONSTRAINT `transaction_groups_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `transaction_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_groups`
--

LOCK TABLES `transaction_groups` WRITE;
/*!40000 ALTER TABLE `transaction_groups` DISABLE KEYS */;
INSERT INTO `transaction_groups` VALUES (1,'2025-10-04 19:48:48','2025-10-04 19:48:48',NULL,1,1,NULL),(2,'2025-10-04 19:48:48','2025-10-04 19:48:48',NULL,1,1,NULL);
/*!40000 ALTER TABLE `transaction_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_journals`
--

DROP TABLE IF EXISTS `transaction_journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_journals` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `transaction_type_id` int unsigned NOT NULL,
  `transaction_group_id` int unsigned DEFAULT NULL,
  `bill_id` int unsigned DEFAULT NULL,
  `transaction_currency_id` int unsigned DEFAULT NULL,
  `description` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `date_tz` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interest_date` date DEFAULT NULL,
  `book_date` date DEFAULT NULL,
  `process_date` date DEFAULT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `tag_count` int unsigned NOT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT '1',
  `completed` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `transaction_journals_user_id_index` (`user_id`),
  KEY `transaction_journals_user_group_id_index` (`user_group_id`),
  KEY `transaction_journals_date_index` (`date`),
  KEY `transaction_journals_transaction_group_id_index` (`transaction_group_id`),
  KEY `transaction_journals_transaction_type_id_index` (`transaction_type_id`),
  KEY `transaction_journals_transaction_currency_id_index` (`transaction_currency_id`),
  KEY `transaction_journals_bill_id_index` (`bill_id`),
  CONSTRAINT `transaction_journals_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transaction_journals_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `transaction_journals_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_journals_transaction_group_id_foreign` FOREIGN KEY (`transaction_group_id`) REFERENCES `transaction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_journals_transaction_type_id_foreign` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_journals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_journals`
--

LOCK TABLES `transaction_journals` WRITE;
/*!40000 ALTER TABLE `transaction_journals` DISABLE KEYS */;
INSERT INTO `transaction_journals` VALUES (1,'2025-10-04 19:48:48','2025-10-04 19:48:48',NULL,1,1,4,1,NULL,1,'Initial balance for \"Commonwealth Bank of Australia\"','2025-10-04 19:48:48','America/Los_Angeles',NULL,NULL,NULL,0,0,1,1),(2,'2025-10-04 19:48:48','2025-10-04 19:48:48',NULL,1,1,4,2,NULL,1,'Initial balance for \"Commonwealth Bank of Australia savings account\"','2025-10-04 19:48:48','America/Los_Angeles',NULL,NULL,NULL,0,0,1,1);
/*!40000 ALTER TABLE `transaction_journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_types`
--

DROP TABLE IF EXISTS `transaction_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_types_type_unique` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_types`
--

LOCK TABLES `transaction_types` WRITE;
/*!40000 ALTER TABLE `transaction_types` DISABLE KEYS */;
INSERT INTO `transaction_types` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Deposit'),(2,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Invalid'),(3,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Liability credit'),(4,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Opening balance'),(5,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Reconciliation'),(6,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Transfer'),(7,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'Withdrawal');
/*!40000 ALTER TABLE `transaction_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `reconciled` tinyint(1) NOT NULL DEFAULT '0',
  `account_id` int unsigned NOT NULL,
  `transaction_journal_id` int unsigned NOT NULL,
  `description` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_currency_id` int unsigned DEFAULT NULL,
  `amount` decimal(32,12) NOT NULL,
  `balance_before` decimal(32,12) DEFAULT NULL,
  `balance_after` decimal(32,12) DEFAULT NULL,
  `balance_dirty` tinyint(1) NOT NULL DEFAULT '1',
  `foreign_amount` decimal(32,12) DEFAULT NULL,
  `foreign_currency_id` int unsigned DEFAULT NULL,
  `identifier` smallint unsigned NOT NULL DEFAULT '0',
  `native_amount` decimal(32,12) DEFAULT NULL,
  `native_foreign_amount` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_account_id_index` (`account_id`),
  KEY `transactions_transaction_journal_id_index` (`transaction_journal_id`),
  KEY `transactions_transaction_currency_id_index` (`transaction_currency_id`),
  KEY `transactions_foreign_currency_id_index` (`foreign_currency_id`),
  CONSTRAINT `transactions_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_foreign_currency_id_foreign` FOREIGN KEY (`foreign_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,0,2,1,NULL,1,-7944.450000000000,0.000000000000,-7944.450000000000,0,NULL,NULL,0,NULL,NULL),(2,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,0,1,1,NULL,1,7944.450000000000,0.000000000000,7944.450000000000,0,NULL,NULL,0,NULL,NULL),(3,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,0,4,2,NULL,1,-52000.000000000000,0.000000000000,-52000.000000000000,0,NULL,NULL,0,NULL,NULL),(4,'2025-10-04 19:48:48','2025-10-04 22:05:00',NULL,0,3,2,NULL,1,52000.000000000000,0.000000000000,52000.000000000000,0,NULL,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_groups_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (1,'2025-10-04 19:44:40','2025-10-04 19:44:40',NULL,'gagneet.singh@gmail.com');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_roles_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'ro'),(2,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_trx'),(3,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_meta'),(4,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_budgets'),(5,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_piggies'),(6,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_subscriptions'),(7,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_rules'),(8,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_recurring'),(9,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_webhooks'),(10,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'read_currencies'),(11,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_budgets'),(12,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_piggies'),(13,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_subscriptions'),(14,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_rules'),(15,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_recurring'),(16,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_webhooks'),(17,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'mng_currencies'),(18,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'view_reports'),(19,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'view_memberships'),(20,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'full'),(21,'2025-10-04 19:30:11','2025-10-04 19:30:11',NULL,'owner');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `objectguid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blocked` tinyint unsigned NOT NULL DEFAULT '0',
  `blocked_code` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mfa_secret` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_user_group_id` (`user_group_id`),
  CONSTRAINT `type_user_group_id` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'2025-10-04 19:44:40','2025-10-04 19:44:40','gagneet.singh@gmail.com','$2y$10$A/mkrhVk/qxAiDyy558IeemGQKF7DEzalmB.k3bagqa4SrWNgH9F.',NULL,NULL,0,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_attempts`
--

DROP TABLE IF EXISTS `webhook_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `webhook_message_id` int unsigned NOT NULL,
  `status_code` smallint unsigned NOT NULL DEFAULT '0',
  `logs` longtext COLLATE utf8mb4_unicode_ci,
  `response` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `webhook_attempts_webhook_message_id_foreign` (`webhook_message_id`),
  CONSTRAINT `webhook_attempts_webhook_message_id_foreign` FOREIGN KEY (`webhook_message_id`) REFERENCES `webhook_messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_attempts`
--

LOCK TABLES `webhook_attempts` WRITE;
/*!40000 ALTER TABLE `webhook_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_deliveries`
--

DROP TABLE IF EXISTS `webhook_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_deliveries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `key` smallint unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_deliveries_key_title_unique` (`key`,`title`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_deliveries`
--

LOCK TABLES `webhook_deliveries` WRITE;
/*!40000 ALTER TABLE `webhook_deliveries` DISABLE KEYS */;
INSERT INTO `webhook_deliveries` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11',300,'JSON');
/*!40000 ALTER TABLE `webhook_deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_messages`
--

DROP TABLE IF EXISTS `webhook_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_messages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `errored` tinyint(1) NOT NULL DEFAULT '0',
  `webhook_id` int unsigned NOT NULL,
  `uuid` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_messages_webhook_id_foreign` (`webhook_id`),
  CONSTRAINT `webhook_messages_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_messages`
--

LOCK TABLES `webhook_messages` WRITE;
/*!40000 ALTER TABLE `webhook_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_responses`
--

DROP TABLE IF EXISTS `webhook_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_responses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `key` smallint unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_responses_key_title_unique` (`key`,`title`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_responses`
--

LOCK TABLES `webhook_responses` WRITE;
/*!40000 ALTER TABLE `webhook_responses` DISABLE KEYS */;
INSERT INTO `webhook_responses` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11',200,'TRANSACTIONS'),(2,'2025-10-04 19:30:11','2025-10-04 19:30:11',210,'ACCOUNTS'),(3,'2025-10-04 19:30:11','2025-10-04 19:30:11',230,'BUDGET'),(4,'2025-10-04 19:30:11','2025-10-04 19:30:11',240,'RELEVANT'),(5,'2025-10-04 19:30:11','2025-10-04 19:30:11',220,'NONE');
/*!40000 ALTER TABLE `webhook_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_triggers`
--

DROP TABLE IF EXISTS `webhook_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_triggers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `key` smallint unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_triggers_key_title_unique` (`key`,`title`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_triggers`
--

LOCK TABLES `webhook_triggers` WRITE;
/*!40000 ALTER TABLE `webhook_triggers` DISABLE KEYS */;
INSERT INTO `webhook_triggers` VALUES (1,'2025-10-04 19:30:11','2025-10-04 19:30:11',50,'ANY'),(2,'2025-10-04 19:30:11','2025-10-04 19:30:11',100,'STORE_TRANSACTION'),(3,'2025-10-04 19:30:11','2025-10-04 19:30:11',110,'UPDATE_TRANSACTION'),(4,'2025-10-04 19:30:11','2025-10-04 19:30:11',120,'DESTROY_TRANSACTION'),(5,'2025-10-04 19:30:11','2025-10-04 19:30:11',200,'STORE_BUDGET'),(6,'2025-10-04 19:30:11','2025-10-04 19:30:11',210,'UPDATE_BUDGET'),(7,'2025-10-04 19:30:11','2025-10-04 19:30:11',220,'DESTROY_BUDGET'),(8,'2025-10-04 19:30:11','2025-10-04 19:30:11',230,'STORE_UPDATE_BUDGET_LIMIT');
/*!40000 ALTER TABLE `webhook_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_webhook_delivery`
--

DROP TABLE IF EXISTS `webhook_webhook_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_webhook_delivery` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` int unsigned NOT NULL,
  `webhook_delivery_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_webhook_delivery_webhook_id_webhook_delivery_id_unique` (`webhook_id`,`webhook_delivery_id`),
  KEY `link_to_delivery` (`webhook_delivery_id`),
  CONSTRAINT `link_to_delivery` FOREIGN KEY (`webhook_delivery_id`) REFERENCES `webhook_deliveries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `webhook_webhook_delivery_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_webhook_delivery`
--

LOCK TABLES `webhook_webhook_delivery` WRITE;
/*!40000 ALTER TABLE `webhook_webhook_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_webhook_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_webhook_response`
--

DROP TABLE IF EXISTS `webhook_webhook_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_webhook_response` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` int unsigned NOT NULL,
  `webhook_response_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_webhook_response_webhook_id_webhook_response_id_unique` (`webhook_id`,`webhook_response_id`),
  KEY `link_to_response` (`webhook_response_id`),
  CONSTRAINT `link_to_response` FOREIGN KEY (`webhook_response_id`) REFERENCES `webhook_responses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `webhook_webhook_response_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_webhook_response`
--

LOCK TABLES `webhook_webhook_response` WRITE;
/*!40000 ALTER TABLE `webhook_webhook_response` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_webhook_response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_webhook_trigger`
--

DROP TABLE IF EXISTS `webhook_webhook_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_webhook_trigger` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` int unsigned NOT NULL,
  `webhook_trigger_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_webhook_trigger_webhook_id_webhook_trigger_id_unique` (`webhook_id`,`webhook_trigger_id`),
  KEY `link_to_trigger` (`webhook_trigger_id`),
  CONSTRAINT `link_to_trigger` FOREIGN KEY (`webhook_trigger_id`) REFERENCES `webhook_triggers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `webhook_webhook_trigger_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_webhook_trigger`
--

LOCK TABLES `webhook_webhook_trigger` WRITE;
/*!40000 ALTER TABLE `webhook_webhook_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_webhook_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `user_group_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `trigger` smallint unsigned NOT NULL,
  `response` smallint unsigned NOT NULL,
  `delivery` smallint unsigned NOT NULL,
  `url` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webhooks_user_id_foreign` (`user_id`),
  KEY `webhooks_title_index` (`title`),
  KEY `webhooks_secret_index` (`secret`),
  KEY `webhooks_to_ugi` (`user_group_id`),
  CONSTRAINT `webhooks_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `webhooks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-05  5:06:23
